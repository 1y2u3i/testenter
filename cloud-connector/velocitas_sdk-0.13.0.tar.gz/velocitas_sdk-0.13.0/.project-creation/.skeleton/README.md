# AppName Readme

A simple skeleton app for getting you up and running with Velocitas app development.
